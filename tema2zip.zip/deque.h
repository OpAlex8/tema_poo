#define DEQUE_H

#include <iostream>
#include "coada.h"

using namespace std;

class Deque: public Coada{
    public:
    int dim_max;
    Nod *prim, *ultim;

    Deque() {
        this->dim_max = 0;
        this->prim = NULL;
        this->ultim = NULL;
    }

    void pop_front() {
        if (this->prim == NULL) {
            return;
        }
        Nod* aux = this->prim;
        this->prim = aux->next;
        delete aux;
        this->dim_max--;
    }

    void pop_back() {
        Nod* p = this->prim;
        while(p->next->next) {
            p = p->next;
        }
        p->next = NULL;
        delete this->ultim;
        this->ultim = p;
        this->dim_max--;
    }

    void push_back(char x) {
        Nod* nod = new Nod;
        nod->info = x;
        nod->next = NULL;
        if (this->dim_max == 0) {
            this->prim = this->ultim = nod;
            this->dim_max++;
            return;
        }
        this->ultim->next = nod;
        this->ultim = nod;
        this->dim_max++;
    }

    void push_front(char x) {
        Nod* nod = new Nod;
        nod->info = x;
        nod->next = this->prim;
        if (this->dim_max == 0) {
            this->prim = this->ultim = nod;
            this->dim_max++;
            return;
        }
        this->prim = nod;
        this->dim_max++;
    }

    ~Deque() {
        cout << "DEQUE DELETED\n";
    }

    friend ostream& operator<<(ostream& os, const Deque& nod);
};

ostream& operator<<(ostream& os, const Deque& nod) {
    Nod* p = nod.prim;
    Nod* aux;
    int i = 1;
    while(p) {
        os << i << ": " << p->info << "\n";
        aux = p;
        p = p->next;
        i++;
        delete aux;
    }
    return os;
}

