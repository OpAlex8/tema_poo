#include "coada.h"
#include <iostream>

using namespace std;

class Deque: public Coada{
    public:
    int dim_max;
    Nod *prim, *ultim;

    Deque() {
        this->dim_max = 0;
        this->prim = NULL;
        this->ultim = NULL;
    }

    void pop_front() {
        if (this->prim == NULL) {
            return;
        }
        Nod* aux = this->prim;
        this->prim = aux->next;
        delete aux;
        this->dim_max--;
    }

    void pop_back() {
        Nod* p = this->prim;
        while(p->next->next) {
            p = p->next;
        }
        p->next = NULL;
        delete this->ultim;
        this->ultim = p;
        this->dim_max--;
    }

    void push_back(char x) {
        Nod* nod = new Nod;
        nod->info = x;
        nod->next = NULL;
        if (this->dim_max == 0) {
            this->prim = this->ultim = nod;
            this->dim_max++;
            return;
        }
        this->ultim->next = nod;
        this->ultim = nod;
        this->dim_max++;
    }

    void push_front(char x) {
        Nod* nod = new Nod;
        nod->info = x;
        nod->next = this->prim;
        if (this->dim_max == 0) {
            this->prim = this->ultim = nod;
            this->dim_max++;
            return;
        }
        this->prim = nod;
        this->dim_max++;
    }

    friend ostream& operator<<(ostream& os, const Deque& nod);
};

ostream& operator<<(ostream& os, const Deque& nod) {
    Nod* p = nod.prim;
    Nod* aux;
    int i = 1;
    while(p) {
        os << i << ": " << p->info << "\n";
        aux = p;
        p = p->next;
        i++;
        delete aux;
    }
    return os;
}

class PQ: public Coada  {
    public:
    void push(char x) {
        if (this->dim_max == 0) {
            Nod* nod = new Nod;
            nod->info = x;
            nod->next = NULL;
            this->prim = this->ultim = nod;
            this->dim_max++;
            return;
        }
        if (x < this->prim->info) {
            Nod* nod = new Nod;
            nod->info = x;
            nod->next = this->prim;
            this->prim = nod;
            this->dim_max++;
            return;
        }
        Nod* p = this->prim;
        while(p->next) {
            if (x < p->next->info) {
                Nod* nod = new Nod;
                nod->info = x;
                nod->next = p->next;
                p->next = nod;
                this->dim_max++;
                return;
            }
            p = p->next;
        }
        Nod* nod = new Nod;
        nod->info = x;
        nod->next = NULL;
        this->ultim->next = nod;
        this->ultim = nod;
        this->dim_max++;
    }
    void pop() {
        if (this->dim_max == 0) {
            return;
        } else if (this->dim_max == 1) {
            this->dim_max = 0;
            this->prim = this->ultim = NULL;
            return;
        }
        Nod* aux = this->prim;
        this->prim = this->prim->next;
        delete aux;
        this->dim_max--;
    }

    friend ostream& operator<<(ostream& os, const PQ& nod);
};

ostream& operator<<(ostream& os, const PQ& nod) {
    Nod* p = nod.prim;
    Nod* aux;
    int i = 1;
    while(p) {
        os << i << ": " << p->info << "\n";
        aux = p;
        p = p->next;
        i++;
        delete aux;
    }
    return os;
}


int main() {
    Deque d;
    PQ p;
    d.push_back('B');
    d.push_back('C');
    d.push_front('A');
    d.push_back('D');
    d.pop_front();
    d.pop_front();
    d.pop_back();

    p.push('A');
    p.push('X');
    p.push('B');
    p.pop();
    p.push('D');
    p.push('E');
    p.pop();
    cout << p;
    return 0;
}
