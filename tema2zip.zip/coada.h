#ifndef COADA_H
#define COADA_H

#include <iostream>

using namespace std;

class Nod{
public:
    Nod* next;
    char info;
    friend class Coada;

    Nod& operator=(const Nod& x) {
        this->info = x.info;
        this->next = x.next;
        return *this;
    }

    Nod& operator+(const Nod& x) {
        this->info = this->info + x.info;
        return *this;
    }

    Nod& operator-(const Nod& x) {
        this->info = this->info - x.info;
        return *this;
    }

    bool operator==(const Nod& x) {
        if (this->info == x.info) {
            return 1;
        }
        return 0;
    }

    bool operator<(const Nod& x) {
        if (this->info < x.info) {
            return 1;
        }
        return 0;
    }

    bool operator>(const Nod& x) {
        if (this->info > x.info) {
            return 1;
        }
        return 0;
    }

    Nod& operator+(char x) {
        this->info = this->info + x;
        return *this;
    }

    Nod& operator-(char x) {
        this->info = this->info - x;
        return *this;
    }

    bool operator==(char x) {
        if (this->info == x) {
            return 1;
        }
        return 0;
    }

    bool operator<(char x) {
        if (this->info < x) {
            return 1;
        }
        return 0;
    }

    bool operator>(char x) {
        if (this->info > x) {
            return 1;
        }
        return 0;
    }

    friend std::istream& operator>>(std::istream& is, const Nod& nod);
    friend std::ostream& operator<<(std::ostream& os, const Nod& nod);
};


std::ostream& operator<<(std::ostream& os, const Nod& nod) {
    os << nod.info;
    return os;
}

std::istream& operator>>(std::istream& is, Nod& nod) {
    is >> nod.info;
    return is;
}

class Coada {
public:
    int dim_max;
    Nod *prim, *ultim;

    Coada() {
        this->dim_max = 0;
        this->prim = NULL;
        this->ultim = NULL;
    }

    void push(char info) {
        if (this->dim_max == 0) {
            Nod* nod = new Nod();
            nod->info = info;
            nod->next = NULL;
            this->prim = this->ultim = nod;
            this->dim_max = 1;
        } else {
            Nod* nod = new Nod();
            Nod* aux = this->ultim;
            nod->info = info;
            nod->next = NULL;
            aux->next = nod;
            this->ultim = nod;
            this->dim_max++;
        }
    }

    void pop(){
        if (this->prim == NULL) {
            return;
        }
        Nod* aux = this->prim;
        this->prim = aux->next;
        delete aux;
        this->dim_max--;
    }

    void top() {
        Nod* aux = this->ultim;
        cout << "Varful cozii este:" << aux->info << "\n";
    }

    Coada& operator+(const Coada& nod) {
        this->ultim = nod.prim;
    }

    Coada& operator-(Coada& nod) {
        Nod* aux;
        int i = 1;
        while (nod.dim_max > 0) {
            Nod* p = nod.prim;
            while(p){
                if (p == nod.prim) {
                    delete p;
                }
                aux = p;
                p = p->next;
                i++;
                delete aux;
            }
            nod.pop();
        }
    }

    friend istream& operator>>(istream& is, const Coada& nod);
    friend ostream& operator<<(ostream& os, const Coada& nod);

    ~Coada() {
        cout << "LIST DELETED\n";
    }
};

istream& operator>>(istream& is, Coada& nod) {
    char x;
    while(1) {
        is >> x;
        if (x == '0') {
            return is;
        }
        nod.push(x);
    }
    return is;
}

ostream& operator<<(ostream& os, const Coada& nod) {
    Nod* p = nod.prim;
    Nod* aux;
    int i = 1;
    while(p) {
        os << i << ": " << p->info << "\n";
        aux = p;
        p = p->next;
        i++;
        delete aux;
    }
    return os;
}

#endif
