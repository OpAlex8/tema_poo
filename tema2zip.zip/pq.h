#define PQ_H

#include <iostream>
#include "coada.h"

using namespace std;

class PQ: public Coada  {
    public:
    void push(char x) {
        if (this->dim_max == 0) {
            Nod* nod = new Nod;
            nod->info = x;
            nod->next = NULL;
            this->prim = this->ultim = nod;
            this->dim_max++;
            return;
        }
        if (x < this->prim->info) {
            Nod* nod = new Nod;
            nod->info = x;
            nod->next = this->prim;
            this->prim = nod;
            this->dim_max++;
            return;
        }
        Nod* p = this->prim;
        while(p->next) {
            if (x < p->next->info) {
                Nod* nod = new Nod;
                nod->info = x;
                nod->next = p->next;
                p->next = nod;
                this->dim_max++;
                return;
            }
            p = p->next;
        }
        Nod* nod = new Nod;
        nod->info = x;
        nod->next = NULL;
        this->ultim->next = nod;
        this->ultim = nod;
        this->dim_max++;
    }
    void pop() {
        if (this->dim_max == 0) {
            return;
        } else if (this->dim_max == 1) {
            this->dim_max = 0;
            this->prim = this->ultim = NULL;
            return;
        }
        Nod* aux = this->prim;
        this->prim = this->prim->next;
        delete aux;
        this->dim_max--;
    }

    ~PQ() {
        cout << "PQ DELETED\n";
    }

    friend ostream& operator<<(ostream& os, const PQ& nod);
};

ostream& operator<<(ostream& os, const PQ& nod) {
    Nod* p = nod.prim;
    Nod* aux;
    int i = 1;
    while(p) {
        os << i << ": " << p->info << "\n";
        aux = p;
        p = p->next;
        i++;
        delete aux;
    }
    return os;
}

